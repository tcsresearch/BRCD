#!/bin/bash
# BLING PreLoader Utility
# Version: 26.05.31

# ShellCheck: Suppress SC1090
# shellcheck source=/dev/null

# ShellCheck: Disable SC2154
# shellcheck disable=SC2154  # Unused variables left for readability
#
#
# TODO: Add to BLING
# 	Enable Cecho

####################################################################################################################################
# Define Files and Folders.																										   #
####################################################################################################################################

# Define Config Directory
  CONFIG_DIR="$(pwd)/config"
  export CONFIG_DIR

# Define Config File  
# CONFIG_FILE="test.ini"
# CONFIG_FILE="config.ini"
  CONFIG_FILE="BRCD_Loader.conf"
  export CONFIG_FILE

# Define Functions Directory
  FUNC_DIR="$(pwd)/functions"
  FUNC_FILE="lib_ini.bfunc"
  export FUNC_DIR
  export FUNC_FILE

# Colors for Cecho-like output
  COLORS_FILE="Colors.conf"
  export COLORS_FILE

# Source our Color Config
if [ -f "$CONFIG_DIR"/$COLORS_FILE ]; then
        source "$CONFIG_DIR"/$COLORS_FILE
fi

####################################################################################################################################
# Display Stuff																													   #
####################################################################################################################################

echo " "
echo "BLING PreLoader Utility"
echo "-----------------------"
echo " "

function DisplayLine() {
	echo " ${brightblue}__________________________________________________${reset}"
}

function NewLine() {
	echo " "
}


####################################################################################################################################
# Source If Exists Function 																									   #
####################################################################################################################################
# Function to source files in a given directory with a specific extension

source_files_if_exist() {
    local dir="$1"
    local pattern="$2"
    if [[ -d "$dir" ]]; then
         echo "${brightwhite} Sourcing files from: ${brightyellow} $dir ${reset}"
	echo "-------------------------------------------------------------------------------------------"
	# Use a glob to find matching files and loop through them
        for file in "$dir"/$pattern; do
            # Check if the glob found actual files (and not just the literal pattern if no files match)
            if [[ -f "$file" ]]; then
                 echo "  ${brightyellow} Sourcing: ${brightblue} $file"
                ### Try using . instead of source source "$file"
            	. "$file"
	    fi
        done
    else
        echo "Directory not found: $dir"
    fi
}

# DisplayLine

####################################################################################################################################
# Source configuration files																									   #
####################################################################################################################################

## source_files_if_exist "config" "*.conf"
source_files_if_exist "$(pwd)/config" "*.conf"
# DisplayLine
NewLine

# Source function files
## source_files_if_exist "functions" "*.bfunc"
source_files_if_exist "$(pwd)/functions" "*.bfunc"
# DisplayLine
NewLine

# Source profile files
## source_files_if_exist "profiles" "*.bprofile"
source_files_if_exist "$(pwd)/profiles" "*.bprofile"
# DisplayLine
NewLine


####################################################################################################################################
# Finish PreLoad																												   #
####################################################################################################################################
# Continue with the rest of your script...

DisplayLine
echo "Advanced Preload Completed."
NewLine

