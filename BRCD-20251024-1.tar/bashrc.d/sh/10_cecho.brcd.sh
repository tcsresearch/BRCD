
# Define Location of Cecho
Location_Cecho="/etc/BLING/NewCecho.bfunc"

# Load function if it exists
if [ -f $Location_Cecho ]; then
    . $Location_Cecho
fi

